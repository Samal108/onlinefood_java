package com.onlinefood.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.onlinefood.entity.UserModel;

@Repository
public interface UserRepository extends JpaRepository<UserModel, String> {
	@Query("SELECT u FROM UserModel u WHERE u.email = :email and u.password = :pass")
	UserModel findUserByEmailAndPassword(@Param("email") String email, @Param("pass") String password);
	
	@Query("SELECT u FROM UserModel u WHERE u.email = :email and u.ststus =1")
	UserModel findUserByEmail(@Param("email") String email);
	
}
