package com.onlinefood.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.onlinefood.entity.RestrurantModel;
import com.onlinefood.entity.UserModel;

@Repository
public interface RestrurantRepository extends JpaRepository<RestrurantModel, Integer> {
	//@Query("SELECT u FROM RestrurantModel u WHERE u.restaurant_id = :id")
	//RestrurantModel findMenuByRestrurant(@Param("id") String id);
	
}
