package com.onlinefood.dto;

public class RegistrationDto {

}
