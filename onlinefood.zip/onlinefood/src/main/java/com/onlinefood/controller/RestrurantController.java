package com.onlinefood.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlinefood.entity.MenuModel;
import com.onlinefood.entity.RestrurantModel;
import com.onlinefood.service.RestrurantService;
import com.onlinefood.util.Response;
import com.onlinefood.util.Util;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/rest")
public class RestrurantController {
	
	@Autowired
	private RestrurantService service;
	
	@GetMapping("/all")  
	private ResponseEntity<?> getAllRestrurant(){
		Response response =null;
		try {
			List<RestrurantModel> restlist = service.getRestrurantService();
			if(restlist!=null && restlist.size()>0) {
				response=Util.getResponse(200, restlist);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}else {
				response=Util.getResponse(505, "Restrurants Not available!");
				 return new ResponseEntity<>(response, HttpStatus.OK);
			}
		}catch(Exception e) {
				response=Util.getResponse(500, "Restrurant service failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@PostMapping("/save")  
	private ResponseEntity<?> userRegistration(@RequestBody RestrurantModel res){
		Response response =null;
		try {
			String saveUser = service.saveResturant(res);
				response=Util.getResponse(200, saveUser);
				return new ResponseEntity<>(response, HttpStatus.OK);
			
		}catch(Exception e) {
			System.out.println(e);
				response=Util.getResponse(500, "Saving Restrurant failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@PostMapping("/save/menu")  
	private ResponseEntity<?> menuSave(@RequestBody MenuModel res){
		Response response =null;
		try {
			String saveUser = service.saveMenu(res);
				response=Util.getResponse(200, saveUser);
				return new ResponseEntity<>(response, HttpStatus.OK);
			
		}catch(Exception e) {
			System.out.println(e);
				response=Util.getResponse(500, "Saving Menu failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
	@PostMapping("/update/menu")  
	private ResponseEntity<?> menuUpdate(@RequestBody MenuModel res){
		Response response =null;
		try {
			String saveUser = service.updateMenu(res);
				response=Util.getResponse(200, saveUser);
				return new ResponseEntity<>(response, HttpStatus.OK);
			
		}catch(Exception e) {
			System.out.println(e);
				response=Util.getResponse(500, "Updating Menu failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
	@DeleteMapping("/delete/menu/{menuid}")  
	private ResponseEntity<?> menuDelete(@PathVariable("menuid") int menuid){
		Response response =null;
		try {
			String deleteUser = service.deleteMenu(menuid);
				response=Util.getResponse(200, deleteUser);
				return new ResponseEntity<>(response, HttpStatus.OK);
			
		}catch(Exception e) {
			System.out.println(e);
				response=Util.getResponse(500, "Deleting Menu failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
	
}
