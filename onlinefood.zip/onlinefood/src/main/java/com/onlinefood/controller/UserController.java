package com.onlinefood.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onlinefood.dto.LoginDto;
import com.onlinefood.entity.UserModel;
import com.onlinefood.service.UserService;
import com.onlinefood.util.Response;
import com.onlinefood.util.Util;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/user")
public class UserController {
	
	@Autowired
	private UserService service;
	
	@PostMapping("/login")  
	private ResponseEntity<?> getLoginUser(@RequestBody LoginDto login){
		Response response =null;
		try {
			UserModel user = service.getLoginService(login);
			if(user!=null) {
				response=Util.getResponse(200, user);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}else {
				response=Util.getResponse(505, "Invalid credentials!");
				 return new ResponseEntity<>(response, HttpStatus.OK);
			}
		}catch(Exception e) {
				response=Util.getResponse(500, "Authentication failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@PostMapping("/registration")  
	private ResponseEntity<?> userRegistration(@RequestBody UserModel user){
		Response response =null;
		try {
			String saveUser = service.saveUser(user);
			if(saveUser.contains("Email already exist")){
				response=Util.getResponse(502, saveUser);
			}else {
				response=Util.getResponse(200, saveUser);
			}
			return new ResponseEntity<>(response, HttpStatus.OK);
			
		}catch(Exception e) {
				response=Util.getResponse(500, "Registration failed !");
			 return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
		}
	}
}
