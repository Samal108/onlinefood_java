package com.onlinefood.util;

public class Util {
	public static Response getResponse(int code,Object obj) {
		Response response = new Response();
		response.setStatusCode(code);
		response.setResp(obj);
		return response;
	}

}
