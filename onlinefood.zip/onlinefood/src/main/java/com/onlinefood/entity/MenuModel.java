package com.onlinefood.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="menu")
public class MenuModel {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="menu_id")
	private Integer id;
	
	@Column(name="item_name")
	private String name;
	
	@Column(name="item_type")
	private String description;
	
	@Column(name="price")
	private Double price;
	
	@Column(name="restaurant_id")
	private Integer restaurant_id;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getRestaurant_id() {
		return restaurant_id;
	}

	public void setRestaurant_id(Integer restaurant_id) {
		this.restaurant_id = restaurant_id;
	}
	
}
