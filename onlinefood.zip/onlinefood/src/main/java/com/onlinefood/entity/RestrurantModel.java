package com.onlinefood.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="restaurants")
public class RestrurantModel {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="restaurant_id")
	private Integer restaurant_id;
	
	@Column(name="name")
	private String restName;
	
	@Column(name="address")
	private String restAddress;
	
	@Column(name="phone")
	private String phone;
	
	
	@OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "restaurant_id", referencedColumnName = "restaurant_id")
    List< MenuModel > menu;

	
	public Integer getRestaurant_id() {
		return restaurant_id;
	}

	public void setRestaurant_id(Integer restaurant_id) {
		this.restaurant_id = restaurant_id;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getRestAddress() {
		return restAddress;
	}

	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public List<MenuModel> getMenu() {
		return menu;
	}

	public void setMenu(List<MenuModel> menu) {
		this.menu = menu;
	}
	
}
