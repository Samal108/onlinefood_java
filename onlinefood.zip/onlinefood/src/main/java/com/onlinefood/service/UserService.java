package com.onlinefood.service;

import com.onlinefood.dto.LoginDto;
import com.onlinefood.entity.UserModel;

public interface UserService {
	public UserModel getLoginService(LoginDto login);
	public String saveUser(UserModel user);
}
