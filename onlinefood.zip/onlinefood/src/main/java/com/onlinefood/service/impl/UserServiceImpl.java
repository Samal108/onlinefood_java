package com.onlinefood.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinefood.dao.UserRepository;
import com.onlinefood.dto.LoginDto;
import com.onlinefood.entity.UserModel;
import com.onlinefood.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepository userRepo;

	@Override
	public UserModel getLoginService(LoginDto login) {
		return userRepo.findUserByEmailAndPassword(login.getEmail(), login.getPassword());
	}

	@Override
	public String saveUser(UserModel user) {
		UserModel existingUser = userRepo.findUserByEmail(user.getEmail());
		if(existingUser==null) {
			userRepo.save(user);
			return "User Register successfully.";
		}else {
			return "Email already exist ! please register with another email.";
		}
		
	}

}
