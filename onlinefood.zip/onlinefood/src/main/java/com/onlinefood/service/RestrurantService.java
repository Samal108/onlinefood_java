package com.onlinefood.service;

import java.util.List;

import com.onlinefood.entity.MenuModel;
import com.onlinefood.entity.RestrurantModel;

public interface RestrurantService {
	public List<RestrurantModel> getRestrurantService();
	public String saveResturant(RestrurantModel menu);
	public String saveMenu(MenuModel menu);
	public String updateMenu(MenuModel menu);
	public String deleteMenu(int id);
	
}
