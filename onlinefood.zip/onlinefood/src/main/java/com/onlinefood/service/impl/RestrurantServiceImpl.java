package com.onlinefood.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onlinefood.dao.MenuRepository;
import com.onlinefood.dao.RestrurantRepository;
import com.onlinefood.dao.UserRepository;
import com.onlinefood.dto.LoginDto;
import com.onlinefood.entity.MenuModel;
import com.onlinefood.entity.RestrurantModel;
import com.onlinefood.entity.UserModel;
import com.onlinefood.service.RestrurantService;
import com.onlinefood.service.UserService;

@Service
public class RestrurantServiceImpl implements RestrurantService{
	@Autowired
	private RestrurantRepository restRepo;
	@Autowired
	private MenuRepository menuRepo;

	@Override
	public List<RestrurantModel> getRestrurantService() {
		return restRepo.findAll();
	}

	@Override
	public String saveResturant(RestrurantModel rest) {
		restRepo.save(rest);
		return "Restrurant save successfully.";
	}

	@Override
	public String saveMenu(MenuModel menu) {
		menuRepo.save(menu);
		return "Menu save successfully.";
	}

	@Override
	public String updateMenu(MenuModel menu) {
		menuRepo.save(menu);
		return "Menu updated successfully.";
	}

	@Override
	public String deleteMenu(int id) {
		menuRepo.deleteById(id);
		return "Menu deleted successfully.";
	}

	

	

}
